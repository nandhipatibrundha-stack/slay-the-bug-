import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest

st.set_page_config(
    page_title="Defence Network Anomaly Detection",
    page_icon="🛡️",
    layout="wide"
)

st.title("🛡️ Defence Network Anomaly Detection")
st.write("Monitor sample network traffic and identify potential anomalies.")

data = pd.DataFrame({
    "flow_duration": [100, 120, 90, 110, 105, 10000, 15000],
    "packets_per_second": [20, 22, 18, 21, 19, 900, 1200],
    "bytes_per_second": [500, 520, 480, 510, 495, 50000, 80000]
})

features = [
    "flow_duration",
    "packets_per_second",
    "bytes_per_second"
]

model = IsolationForest(
    contamination=0.25,
    random_state=42
)
model.fit(data[features])

st.subheader("Analyze Network Traffic")

col1, col2, col3 = st.columns(3)

with col1:
    duration = st.number_input(
        "Flow duration", min_value=0.0, value=100.0
    )

with col2:
    packets = st.number_input(
        "Packets per second", min_value=0.0, value=20.0
    )

with col3:
    bytes_rate = st.number_input(
        "Bytes per second", min_value=0.0, value=500.0
    )

if st.button("Analyze Traffic"):
    sample = pd.DataFrame([[
        duration, packets, bytes_rate
    ]], columns=features)

    result = model.predict(sample)[0]

    if result == -1:
        st.error("⚠️ Potential anomaly detected!")
    else:
        st.success("✅ No anomaly flagged by the model.")

    st.write("Input traffic:")
    st.dataframe(sample, use_container_width=True)

st.subheader("Example Network Traffic")
st.dataframe(data, use_container_width=True)

st.info(
    "Educational prototype only. Predictions use a small "
    "sample dataset and must not be used for real defence "
    "or security decisions."
)
